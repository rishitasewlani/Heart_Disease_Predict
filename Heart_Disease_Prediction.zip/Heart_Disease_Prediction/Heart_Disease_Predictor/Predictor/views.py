from django.shortcuts import render

# Create your views here.
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

def home(request):
    return render(request, 'home.html')

def predict(request):
    return render(request, 'predict.html')

def result(request):
    sample_of_data = pd.read_csv('D:/FIYA/Skills/PROJECT/heart.csv')
    X = sample_of_data.drop(columns='HeartDisease', axis=1)
    Y = sample_of_data['HeartDisease']

    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, stratify=Y, random_state=2)
    model = LogisticRegression()

    model.fit(X_train, Y_train)

    val1 = float(request.GET['age'])
    val2 = float(request.GET['sex'])
    if request.method == 'POST':
        selection = request.POST.get('sex')
        if selection == '0':
            val2 = 0
        elif selection == '1':
            val2 = 1
        else:
            return render(request, 'home.html', {"result": "Incorrect inputs"})

    val3 = float(request.GET['chestPain'])
    if request.method == 'POST':
        selection = request.POST.get('chestPain')
        if selection == '1':
            val3 = 1
        elif selection == '2':
            val3 = 2
        elif selection == '3':
            val3 = 3
        elif selection == '4':
            val3 = 4
        else:
            return render(request, 'home.html', {"result": "Incorrect inputs"})

    val4 = float(request.GET['restingBP'])
    val5 = float(request.GET['cholesterol'])
    val6 = float(request.GET['fastingBS'])
    if request.method == 'POST':
        selection = request.POST.get('fastingBS')
        if selection == '1':
            val6 = 1
        elif selection == '0':
            val6 = 0
        else:
            return render(request, 'home.html', {"result": "Incorrect inputs"})

    val7 = float(request.GET['restingECG'])
    if request.method == 'POST':
        selection = request.POST.get('restingECG')
        if selection == '1':
            val7 = 1
        elif selection == '2':
            val7 = 2
        elif selection == '3':
            val7 = 3
        else:
            return render(request, 'home.html', {"result": "Incorrect inputs"})

    val8 = float(request.GET['maxHR'])
    val9 = float(request.GET['exerciseAngina'])
    if request.method == 'POST':
        selection = request.POST.get('exerciseAngina')
        if selection == '0':
            val9 = 0
        elif selection == '1':
            val9 = 1
        else:
            return render(request, 'home.html', {"result": "Incorrect inputs"})

    val10 = float(request.GET['oldPeak'])
    val11 = float(request.GET['srSlope'])

    pred = model.predict([[val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11]])

    result1 = ""

    if pred == [1]:
        result1 = "You might have a heart disease, Kindly consult your doctor!"
    else:
        result1 = "You do not have a heart disease!"

    return render(request, 'home.html', {"result": result1})
